GRANT INSERT, UPDATE, DELETE ON public.artists TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.portfolio_media TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.availability_slots TO authenticated;