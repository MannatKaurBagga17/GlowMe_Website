import { useEffect, useState } from "react";
import glowmeLogo from "@/assets/glowme-logo.png";

export function SplashScreen() {
  const [show, setShow] = useState(true);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("gm_splash_done") === "1") {
      setShow(false);
      return;
    }
    const leaveT = window.setTimeout(() => setLeaving(true), 2400);
    const hideT = window.setTimeout(() => {
      setShow(false);
      sessionStorage.setItem("gm_splash_done", "1");
    }, 3100);
    return () => {
      window.clearTimeout(leaveT);
      window.clearTimeout(hideT);
    };
  }, []);

  if (!show) return null;

  const sparkles = Array.from({ length: 18 });

  return (
    <div className={`gm-splash${leaving ? " gm-splash-out" : ""}`} aria-hidden>
      <style>{`
        .gm-splash{
          position:fixed;inset:0;z-index:9999;
          background:#080808;
          display:flex;align-items:center;justify-content:center;
          overflow:hidden;
          opacity:1;transition:opacity .7s ease;
          font-family:'Playfair Display', serif;
        }
        .gm-splash-out{opacity:0;pointer-events:none;}
        .gm-splash::before{
          content:'';position:absolute;inset:-20%;
          background:radial-gradient(circle at center, rgba(201,169,110,0.10), transparent 60%);
          filter:blur(40px);
          animation: gmGlow 2.6s ease-in-out infinite alternate;
        }
        @keyframes gmGlow{from{opacity:.4;transform:scale(.95)}to{opacity:.7;transform:scale(1.05)}}
        .gm-splash-logo{
          position:relative;z-index:2;
          font-size:clamp(48px, 9vw, 96px);
          font-weight:700;letter-spacing:.06em;
          color:#F5F0E8;
          opacity:0;transform:scale(.95);
          animation: gmReveal 1.2s cubic-bezier(.2,.7,.2,1) .15s forwards;
          text-shadow:0 0 40px rgba(201,169,110,0.35);
        }
        .gm-splash-logo em{
          font-style:italic;
          background:linear-gradient(90deg,#9A7A45 0%, #E8D5A3 45%, #C9A96E 60%, #E8D5A3 80%, #9A7A45 100%);
          background-size:200% 100%;
          -webkit-background-clip:text;background-clip:text;color:transparent;
          animation: gmSweep 2.4s linear .8s infinite;
        }
        @keyframes gmReveal{
          0%{opacity:0;transform:scale(.95)}
          100%{opacity:1;transform:scale(1)}
        }
        @keyframes gmSweep{
          0%{background-position:200% 0}
          100%{background-position:-200% 0}
        }
        .gm-splash-img{
          position:relative;z-index:2;
          width:clamp(240px, 60vw, 460px);
          height:auto;border-radius:50%;
          opacity:0;transform:scale(.92);
          animation: gmReveal 1.2s cubic-bezier(.2,.7,.2,1) .15s forwards;
          filter:drop-shadow(0 0 28px rgba(201,169,110,0.18));
        }
        @keyframes gmFade{to{opacity:1}}
        .gm-sparkle{
          position:absolute;width:4px;height:4px;border-radius:50%;
          background:#E8D5A3;box-shadow:0 0 8px rgba(232,213,163,0.9), 0 0 14px rgba(201,169,110,0.6);
          opacity:0;
        }
        @keyframes gmFloat{
          0%{transform:translate(0,0) scale(.4);opacity:0}
          25%{opacity:1}
          100%{transform:translate(var(--dx), var(--dy)) scale(1);opacity:0}
        }
      `}</style>
      {sparkles.map((_, i) => {
        const left = Math.random() * 100;
        const top = 30 + Math.random() * 50;
        const dx = (Math.random() - 0.5) * 120;
        const dy = -(40 + Math.random() * 120);
        const delay = Math.random() * 1.6;
        const dur = 2.4 + Math.random() * 1.6;
        const size = 2 + Math.random() * 4;
        return (
          <span
            key={i}
            className="gm-sparkle"
            style={{
              left: `${left}%`,
              top: `${top}%`,
              width: `${size}px`,
              height: `${size}px`,
              ["--dx" as never]: `${dx}px`,
              ["--dy" as never]: `${dy}px`,
              animation: `gmFloat ${dur}s ease-out ${delay}s infinite`,
            }}
          />
        );
      })}
      <img
        className="gm-splash-img"
        src={glowmeLogo}
        alt="GlowMe — Beauty Marketplace"
        width={1024}
        height={1024}
      />
    </div>
  );
}
