import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { getMyArtist } from "@/lib/artist-dashboard.functions";
import { User, Heart, Calendar, MessageCircle, Search, LayoutDashboard } from "lucide-react";

export function SiteHeader() {
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setSignedIn(!!session));
    return () => sub.subscription.unsubscribe();
  }, []);

  const fetchMine = useServerFn(getMyArtist);
  const { data: mine } = useQuery({
    queryKey: ["my-artist-header"],
    queryFn: () => fetchMine(),
    enabled: signedIn,
    staleTime: 60_000,
  });
  const isArtist = !!mine?.artist;

  return (
    <header className="gm-header">
      <style>{`
        .gm-header{
          --gold:#C9A96E;--cream:#F5F0E8;--muted:#8A7D70;
          position:sticky;top:0;z-index:40;
          background:rgba(8,8,8,0.85);backdrop-filter:blur(14px);
          border-bottom:0.5px solid rgba(201,169,110,0.18);
          font-family:'Jost',sans-serif;font-weight:300;
        }
        .gm-header-inner{max-width:1280px;margin:0 auto;padding:18px 24px;display:flex;align-items:center;justify-content:space-between;gap:24px;}
        .gm-brand{font-family:'Playfair Display',serif;font-size:24px;font-weight:700;letter-spacing:0.06em;color:var(--cream);text-decoration:none;}
        .gm-brand em{font-style:italic;color:var(--gold);font-weight:700;}
        .gm-nav{display:none;align-items:center;gap:28px;}
        @media(min-width:780px){.gm-nav{display:flex;}}
        .gm-nav a{display:inline-flex;align-items:center;gap:6px;color:rgba(245,240,232,0.6);text-decoration:none;font-size:11px;letter-spacing:0.2em;text-transform:uppercase;transition:color .25s;}
        .gm-nav a:hover{color:var(--gold);}
        .gm-actions{display:flex;align-items:center;gap:14px;}
        .gm-heart{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;border:0.5px solid rgba(201,169,110,0.4);color:var(--gold);text-decoration:none;transition:all .3s;border-radius:50%;}
        .gm-heart:hover{background:var(--gold);color:#080808;}
        .gm-cta{display:inline-flex;align-items:center;gap:8px;background:var(--gold);color:#080808;padding:10px 20px;font-size:10px;font-weight:500;letter-spacing:0.22em;text-transform:uppercase;text-decoration:none;transition:all .3s;}
        .gm-cta:hover{background:#E8D5A3;}
        .gm-account{display:inline-flex;align-items:center;gap:8px;border:0.5px solid rgba(201,169,110,0.4);color:var(--gold);padding:10px 18px;font-size:10px;font-weight:400;letter-spacing:0.22em;text-transform:uppercase;text-decoration:none;transition:all .3s;}
        .gm-account:hover{background:var(--gold);color:#080808;}
      `}</style>
      <div className="gm-header-inner">
        <Link to="/" className="gm-brand">Glow<em>Me</em></Link>
        <nav className="gm-nav">
          {!isArtist && <Link to="/search"><Search className="h-3.5 w-3.5" /> Discover</Link>}
          {signedIn && !isArtist && (
            <>
              <Link to="/account"><Calendar className="h-3.5 w-3.5" /> Bookings</Link>
              <Link to="/favourites"><Heart className="h-3.5 w-3.5" /> Saved</Link>
              <Link to="/support"><MessageCircle className="h-3.5 w-3.5" /> Support</Link>
            </>
          )}
          {signedIn && isArtist && <Link to="/dashboard"><LayoutDashboard className="h-3.5 w-3.5" /> Artist Dashboard</Link>}
        </nav>
        <div className="gm-actions">
          {signedIn && !isArtist && (
            <Link to="/favourites" className="gm-heart" aria-label="Saved artists">
              <Heart className="h-4 w-4" />
            </Link>
          )}
          {signedIn ? (
            <Link to={isArtist ? "/dashboard" : "/account"} className="gm-account"><User className="h-3.5 w-3.5" /> {isArtist ? "Dashboard" : "Account"}</Link>
          ) : (
            <Link to="/auth" className="gm-cta">Sign in</Link>
          )}
        </div>
      </div>
    </header>
  );
}
