import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarMenu,
  SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, SidebarHeader,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard, CalendarCheck, User, Image, Briefcase, Clock, MapPin,
  MessageSquare, Star, Wallet, Bell, Settings, LogOut,
} from "lucide-react";
import type { ReactNode } from "react";

const NAV = [
  { url: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { url: "/bookings", label: "Bookings", icon: CalendarCheck },
  { url: "/profile", label: "Profile", icon: User },
  { url: "/portfolio", label: "Portfolio", icon: Image },
  { url: "/services", label: "Services & Pricing", icon: Briefcase },
  { url: "/availability", label: "Availability", icon: Clock },
  { url: "/service-areas", label: "Service Areas", icon: MapPin },
  { url: "/messages", label: "Messages", icon: MessageSquare },
  { url: "/reviews", label: "Reviews & Ratings", icon: Star },
  { url: "/earnings", label: "Earnings", icon: Wallet },
  { url: "/notifications", label: "Notifications", icon: Bell },
  { url: "/settings", label: "Settings", icon: Settings },
] as const;

function ArtistSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const qc = useQueryClient();

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-border px-4 py-4">
        <Link to="/dashboard" className="font-serif text-lg tracking-wide">
          Glow<span className="italic text-primary">Me</span> <span className="text-xs uppercase tracking-widest text-muted-foreground">Artist</span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {NAV.map((item) => {
                const active = item.url === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(item.url);
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={active} tooltip={item.label}>
                      <Link to={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
              <SidebarMenuItem>
                <SidebarMenuButton onClick={signOut} tooltip="Sign out">
                  <LogOut className="h-4 w-4" /><span>Logout</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}

export function ArtistShell({ children, title }: { children: ReactNode; title?: string }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <ArtistSidebar />
        <div className="flex flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border bg-background/95 px-4 backdrop-blur">
            <SidebarTrigger />
            {title && <h1 className="font-serif text-lg">{title}</h1>}
          </header>
          <main className="flex-1 p-4 md:p-6">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
