import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import "@/glowme/glowme.css";
import bodyHtml from "@/glowme/body.html?raw";
import inlineJs from "@/glowme/inline.js?raw";
import { listArtists } from "@/lib/glowme.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GlowMe — Luxury Beauty Marketplace" },
      {
        name: "description",
        content:
          "India's luxury beauty marketplace. Book verified makeup artists, salons, and nail specialists with live calendars and AI-powered recommendations.",
      },
      { property: "og:title", content: "GlowMe — Luxury Beauty Marketplace" },
      {
        property: "og:description",
        content:
          "Discover and book India's finest makeup artists, curated salons, and nail specialists.",
      },
    ],
    links: [
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,700;1,400;1,500&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=Jost:wght@200;300;400;500&display=swap",
      },
    ],
  }),
  component: GlowMePage,
});

function escapeHtml(s: string) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function renderArtistCard(a: any, idx: number) {
  const price = Math.round(Number(a.base_price_paise || 0) / 100);
  const rating = Number(a.avg_rating || 0).toFixed(1);
  const reviews = Number(a.review_count || 0);
  const tags = (a.specialties ?? []).slice(0, 3).map((t: string) => `<span class="atag">${escapeHtml(t)}</span>`).join("");
  const fullStars = Math.round(Number(a.avg_rating || 0));
  const stars = "★".repeat(Math.max(0, Math.min(5, fullStars))) + "☆".repeat(Math.max(0, 5 - fullStars));
  const img = escapeHtml(a.hero_image_url || a.avatar_url || "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=600&q=80&fit=crop&crop=face");
  const avail = a.offers_at_home || a.offers_studio ? '<div class="artist-avail">Available today</div>' : "";
  return `
  <a href="/artist/${escapeHtml(a.slug)}" class="artist-card reveal d${(idx % 6) + 1}" style="text-decoration:none;color:inherit" data-price="${price}" data-rating="${rating}">
    <div class="artist-img">
      <img src="${img}" alt="${escapeHtml(a.name)}" loading="lazy">
      ${avail}
    </div>
    <div class="artist-info">
      <div class="artist-name-row"><span class="artist-name">${escapeHtml(a.name)}</span><div class="artist-rate">₹${price.toLocaleString()}<span>starting from</span></div></div>
      <div class="artist-loc">📍 ${escapeHtml(a.city || "")}${a.area ? ", " + escapeHtml(a.area) : ""}</div>
      <div class="artist-tags">${tags}</div>
      <div class="artist-footer">
        <div><span class="stars">${stars}</span><span class="rating-txt">${rating} (${reviews})</span></div>
        <div><span class="book-btn">View profile</span></div>
      </div>
    </div>
  </a>`;
}

function GlowMePage() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ensureRazorpay = () =>
      new Promise<void>((resolve) => {
        if (document.querySelector('script[data-glowme="razorpay"]')) {
          resolve();
          return;
        }
        const s = document.createElement("script");
        s.src = "https://checkout.razorpay.com/v1/checkout.js";
        s.async = true;
        s.dataset.glowme = "razorpay";
        s.onload = () => resolve();
        s.onerror = () => resolve();
        document.head.appendChild(s);
      });

    let injected: HTMLScriptElement | null = null;
    let cancelled = false;
    ensureRazorpay().then(async () => {
      injected = document.createElement("script");
      injected.dataset.glowme = "inline";
      injected.text = inlineJs;
      document.body.appendChild(injected);
      try { document.dispatchEvent(new Event("DOMContentLoaded")); } catch {}

      // Replace the hard-coded "Featured artists" grid with live data.
      try {
        const res = await listArtists({ data: {} });
        if (cancelled) return;
        const grid = document.getElementById("artistsGrid");
        const artists = res?.artists ?? [];
        if (grid && artists.length > 0) {
          grid.innerHTML = artists.slice(0, 9).map((a, i) => renderArtistCard(a, i)).join("");
          // Re-trigger reveal animations on the new nodes
          grid.querySelectorAll(".reveal").forEach((el) => el.classList.add("in"));
        }
      } catch {}
    });

    return () => {
      cancelled = true;
      if (injected && injected.parentNode) injected.parentNode.removeChild(injected);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      dangerouslySetInnerHTML={{ __html: bodyHtml }}
    />
  );
}
